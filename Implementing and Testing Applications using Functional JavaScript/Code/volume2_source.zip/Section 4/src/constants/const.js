export const WEATHER_API_KEY = 'b8bffe1d7ed810538b0bbdb3af3fe14b';
export const GOOGLE_TIMEZONE_API_KEY = 'AIzaSyCte5z26RhIxMYyrM8dmP-pELhy4VS9bIw';